<?php
$nome = $_POST['nome'];
echo "<h3>Cadastro realizado com sucesso para o usuario $nome";
?>