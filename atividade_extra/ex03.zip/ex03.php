<?php
$dolares = $_POST['valor'];
$reais = $dolares * 5.59;
echo "<h3>Conversor de moedas</h3>";
echo "<p>US$$dolares são R$$reais</p>";
?>